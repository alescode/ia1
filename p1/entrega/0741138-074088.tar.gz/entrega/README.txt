dodgson:
    Toma un perfil de preferencias electorales e informa al usuario
    cuál sería el candidato "ganador Dodgson", así como
    del número de cambios elementales mínimo que se requiere hacer
    sobre las preferencias de los electores para que triunfe este
    candidato.
    También informa cuántos nodos generó y expandió el algoritmo
    de búsqueda utilizado para llegar a una solución.

Requerimientos técnicos:
    Compilador g++ (gcc) 4.2 o superior
    Librerías estándar de C++
    Recomendado: 1 GB de memoria RAM o superior
                 Procesador Intel Pentium 4 o superior


