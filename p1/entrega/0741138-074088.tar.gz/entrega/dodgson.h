#ifndef _DOGSON
	#define _DOGSON

#include "IDAestrella.h"
#include "BFS.h"

#endif